# very-simple-gallery

This is the most very simple responsive gallery using only CSS an JS

Thats code is part of one tutorial about how to create a simple gallery using only CSS and JS. If you would like to see it, 
please check this link: https://goo.gl/T3P7az

version: 1.0


